#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
    struct node *prev;
};
struct node *head,*new;
void insertf(){
    new = (struct node *)malloc(sizeof(struct node));
    printf("Enter data: ");
    scanf("%d",&new->data);
    new->prev=0;
    new->next=0;
    head->prev=new;
    new->next=head;
    head=new;
}

void deletef(){
    struct node *temp;
    if(head==0){
        printf("Empty List");
    }
    else{
        temp=head;
        head=head->next;
        head->prev=0;
        free(temp);
    }
}
void create(){
    struct node *temp;
    head=0;
    int choice = 1;
    while(choice){
    new = (struct node *)malloc(sizeof(struct node));
    printf("ENter data: ");
    scanf("%d",&new->data);
    new->next=0;
    new->prev=0;
    if(head==0){
        head=temp=new;
    }
    else{
        temp->next=new;
        new->prev=temp;
        temp=new;
        
    }
        printf("Do you want to continue: (0,1)");
        scanf("%d",&choice);
}
    
}
void display(){
    struct node *temp;
    temp=head;
    int choice=0;
    while(temp!=0){
        printf("%d",temp->data);
        temp=temp->next;

    }
}
 int main(){
     create();
     int i;
     for(i=0;i<4;i++){
     printf("1.Insert\n 2. Delete\n 3. Display\n");
     scanf("%d",&i);
     switch(i){
         case 1:
         insertf();
         break;
         
         case 2:
         deletef();
         break;
         
         case 3:
         display();
         break;
     }
     }
 }
     
 
 

