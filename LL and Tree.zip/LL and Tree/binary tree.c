#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *lptr;
    struct node *rptr;
};
void preorder(struct node *);
void inorder(struct node *);
void postorder(struct node *);

void inorder(struct node*t){
    if(t==NULL){
        printf("Empty");
    }
    else{
    
    if(t->lptr!=NULL){
        inorder(t->lptr);
    }
        printf("%d",t->data);
    
    if(t->rptr!=NULL){
        inorder(t->rptr);
    }
    }
}
void postorder(struct node*t){
    if(t==NULL){
        printf("Empty");
    }
    else{
    
    if(t->lptr!=NULL){
        postorder(t->lptr);
    }
    if(t->rptr!=NULL){
        postorder(t->rptr);
    }
        printf("%d",t->data);
}
}

void preorder(struct node *t){
    if(t==NULL){
        printf("Empty tree");
    }    
    else{
        printf("%d",t->data);
    
    if(t->lptr!=NULL){
        preorder(t->lptr);
    }
    if(t->rptr!=NULL){
        preorder(t->rptr);
    }
} 
}

void main(){
struct node *first,*second,*third,*fourth,*fifth,*sixth,*seventh,*t;
first = (struct node *)malloc(sizeof(struct node));
second = (struct node *)malloc(sizeof(struct node));
third = (struct node *)malloc(sizeof(struct node));
fourth = (struct node *)malloc(sizeof(struct node));
fifth = (struct node *)malloc(sizeof(struct node));
sixth = (struct node *)malloc(sizeof(struct node));
seventh = (struct node *)malloc(sizeof(struct node));
t=first;
first->data=5;
first->lptr=second;
first->rptr=fourth;

second->data=6;
second->lptr=third;
second->rptr=NULL;

third->data=7;
third->lptr=NULL;
third->rptr=NULL;

fourth->data=8;
fourth->lptr=fifth;
fourth->rptr=seventh;

fifth->data=9;
fifth->lptr=NULL;
fifth->rptr=sixth;

sixth->data=10;
sixth->lptr=NULL;
sixth->rptr=NULL;

seventh->data=11;
seventh->lptr=NULL;
seventh->rptr=NULL;
printf("Preorder Tree is: \n");
preorder(t);
printf("\nInorder tree is: ");
inorder(t);
printf("\nPostorder tree is: ");
postorder(t);
printf("\nDone");
}