#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
};
struct node *head,*new,*tail;
void insertf(){
    new = (struct node *)malloc(sizeof(struct node));
    printf("Enter data: ");
    scanf("%d",&new->data);
    if(tail==0){
    tail=new;
    tail->next=new;
    }
    else{
        new->next=tail->next;
        tail->next=new;
    }
}

void inserte(){
    new = (struct node *)malloc(sizeof(struct node));
    printf("Enter data: ");
    scanf("%d",&new->data);
    if(tail==0){
    tail=new;
    tail->next=new;
    }
    else{
        new->next=tail->next;
        tail->next=new;
        tail=new;
    }
}


void deletef(){
    struct node *temp;
    temp=tail->next;
    if(tail==0){
        printf("Empty List");
    }
    else if(temp->next==temp){
        tail=0;
        free(temp);
    }
    else{
        tail->next=temp->next;
        free(temp);
    }
}
void deletee(){
    struct node *present,*prev;
    present=tail->next;
    if(tail==0){
        printf("Empty List");
    }
    else if(present->next==present){
        tail=0;
        free(present);
    }
    else{
        prev=present;
        present=present->next;
    }
    prev->next=tail->next;
    tail=prev;
    free(present);
    
}


void create(){
    struct node *temp;
    head=0;
    int choice = 1;
    while(choice){
    new = (struct node *)malloc(sizeof(struct node));
    printf("ENter data: ");
    scanf("%d",&new->data);
    new->next=0;
    if(head==0){
        head=temp=new;
    }
    else{
        temp->next=new;
        temp=new;
        
    }
        temp->next=head;
        printf("Do you want to continue: (0,1)");
        scanf("%d",&choice);
}
    
}
void display(){
    struct node *temp;
    temp=head;
    int choice=0; 
    while(temp->next!=head){
        printf("%d",temp->data);
        temp=temp->next;
        
    }
    printf("%d",temp->data);
    
}


 int main(){
     create();
     int i;
     for(i=0;i<5;i++){
     printf(" 1.Insert from beginning\n 2. Insert from end\n 3.Display\n 4. Delete from beginning\n 5. Delete from end\n ");
     scanf("%d",&i);
     switch(i){
         case 1:
         insertf();
         break;
         
         case 2:
         inserte();
         break;
         
         case 3:
         display();
         break;
         
         case 4:
         deletef();
         break;
         
         case 5:
         deletee();
        break;
         
     }
     }
 }
     
 
 

