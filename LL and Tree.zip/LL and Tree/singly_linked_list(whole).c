#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
};
struct node *head,*new;
void insertf(){
    new = (struct node *)malloc(sizeof(struct node));
    printf("Enter data: ");
    scanf("%d",&new->data);
    new->next=head;
    head=new;
}

void inserte(){
    struct node *temp;
    new = (struct node *)malloc(sizeof(struct node));
    printf("Enter data: ");
    scanf("%d",&new->data); 
    new->next=0;
    temp=head;
    while(temp->next!=0){
        temp=temp->next;
        temp->next=new;
    }
}


void deletef(){
    struct node *temp;
    if(head==0){
        printf("Empty List");
    }
    else{
        temp=head;
        head=head->next;
        free(temp);
    }
}
void copy(){
    if(head==NULL){
        printf("Empty");
    }
    else{
        new = (struct node *)malloc(sizeof(struct node));
        new->data=head->data;
        new->next=head->next;
    }
}
void create(){
    struct node *temp;
    head=0;
    int choice = 1;
    while(choice){
    new = (struct node *)malloc(sizeof(struct node));
    printf("ENter data: ");
    scanf("%d",&new->data);
    new->next=0;
    if(head==0){
        head=temp=new;
    }
    else{
        temp->next=new;
        temp=new;
        
    }
        printf("Do you want to continue: (0,1)");
        scanf("%d",&choice);
}
    
}
void display(){
    struct node *temp;
    temp=head;
    int choice=0; 
    while(temp!=0){
        printf("%d",temp->data);
        temp=temp->next;

    }
}

void count(){
    struct node *temp;
    temp=head;
    int choice=0;
    int count=0;
    while(temp!=0){
        temp=temp->next;
        count++;
}
printf("\n%d\n",count);
}
 int main(){
     create();
     int i;
     for(i=0;i<7;i++){
     printf(" 1.Insert from beginning\n 2. Insert from end\n 3. Display\n 4. Delete\n 5. Copy\n 6. Count\n");
     scanf("%d",&i);
     switch(i){
         case 1:
         insertf();
         break;
         
         case 2:
         inserte();
         break;
         
         case 3:
         display();
         break;
         
         case 4:
         deletef();
         break;
         
         case 5:
         copy();
         break;
         
         case 6:
         count();
         break;
         
         
     }
     }
 }
     
 
 

